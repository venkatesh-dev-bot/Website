import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { ChatMessage } from '../types';

const modelOptions = [
    { label: "GPT", value: "GPT" },
    { label: "Gemini", value: "GEMINI" },
    { label: "Mistral", value: "MISTRAL" },
];

export default function Chatbot() {
    const [messages, setMessages] = useState<ChatMessage[]>([
        {
            id: '1',
            content: "Hello! I'm Venkatesh, an AI Engineer. How can I help you today?",
            sender: 'bot',
            timestamp: new Date(),
        },
    ]);
    
    const [input, setInput] = useState('');
    const [selectedModel, setSelectedModel] = useState(modelOptions[0].value); // Default to first option
    const [isLoading, setIsLoading] = useState(false); // Loading state

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMessage: ChatMessage = {
            id: Date.now().toString(),
            content: input,
            sender: 'user',
            timestamp: new Date(),
        };

        // Add the user's message to the chat history
        setMessages((prev) => [...prev, userMessage]);
        setInput(''); // Clear the input field
        
        // Set loading state to true
        setIsLoading(true);

        try {
            const response = await fetch('https://525e-27-4-58-200.ngrok-free.app/ask', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: input,
                    model: selectedModel,  // Use the selected model
                }),
            });

            // Check if the response was successful
            if (!response.ok) {
                const errorDetails = await response.json();
                throw new Error(`Error ${response.status}: ${errorDetails.detail}`);
            }

            const result = await response.json();

            const botMessage: ChatMessage = {
                id: (Date.now() + 1).toString(),
                content: result.answer,
                sender: 'bot',
                timestamp: new Date(),
            };

            // Add the bot's response to the chat history
            setMessages((prev) => [...prev, botMessage]);

        } catch (error) {
            console.error('Error:', error);
            const errorMessage: ChatMessage = {
                id: Date.now().toString(),
                content: "I'm sorry, there was an error processing your request.",
                sender: 'bot',
                timestamp: new Date(),
            };
            setMessages((prev) => [...prev, errorMessage]);
        } finally {
            // Set loading state to false after processing
            setIsLoading(false);
        }
    };

    return (
        <section id="chat" className="py-20 bg-gray-50"> {/* Updated background for better aesthetics */}
            <div className="container mx-auto px-6">
                <h2 className="text-4xl font-bold text-center mb-16">Chat with Me</h2>
                <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
                    <div className="h-[400px] overflow-y-auto p-6">
                        {messages.map((message) => (
                            <div
                                key={message.id}
                                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
                            >
                                <div 
                                    className={`max-w-[70%] rounded-lg p-3 ${
                                        message.sender === 'user'
                                        ? 'bg-indigo-600 text-white'
                                        : 'bg-gray-100 shadow-md'
                                    }`}
                                >
                                    <p>{message.content}</p>
                                    <span className="text-xs opacity-75 mt-1 block">
                                        {message.timestamp.toLocaleTimeString()}
                                    </span>
                                </div>
                            </div>
                        ))}
                        {isLoading && (
                            <div className="flex justify-center mb-4">
                                <span className="loader">Loading...</span> {/* Add a simple loading indicator */}
                            </div>
                        )}
                    </div>
                    <form onSubmit={handleSubmit} className="p-4 bg-gray-50 border-t">
                        <div className="flex flex-col space-y-4">
                            <div className="flex space-x-4">
                                <select
                                    value={selectedModel}
                                    onChange={(e) => setSelectedModel(e.target.value)}
                                    className="border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                >
                                    {modelOptions.map((option) => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </select>
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Type your message..."
                                    className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                                <button
                                    type="submit"
                                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                                >
                                    <Send size={20} />
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    );
}