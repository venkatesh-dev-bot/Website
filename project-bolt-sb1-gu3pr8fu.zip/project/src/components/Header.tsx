import React from 'react';
import { Menu, X, Github, Linkedin, Mail } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <header className="fixed w-full bg-white/80 backdrop-blur-sm z-50 shadow-sm">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <a href="#home" className="text-2xl font-bold text-gray-800">
            Venkatesh Kunchala
          </a>
          
          <div className="hidden md:flex items-center space-x-8">
            
            <a
              href="#projects"
              className="text-gray-600 hover:text-gray-900"
              onClick={(e) => {
                e.preventDefault();
                const section = document.getElementById('projects');
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
            >
              Projects
            </a>
            
            <a
              href="#skills"
              className="text-gray-600 hover:text-gray-900"
              onClick={(e) => {
                e.preventDefault();
                const section = document.getElementById('skills');
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
            >
              Skills
            </a>
            
            <a
              href="#chat"
              className="text-gray-600 hover:text-gray-900"
              onClick={(e) => {
                e.preventDefault();
                const section = document.getElementById('chat');
                section.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
            >
              Chat
            </a>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <a
              href="https://github.com/venkatesh-dev-bot"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-900"
            >
              <Github size={20} />
            </a>
            <a
              href="https://www.linkedin.com/in/venkatesh-kunchala-46741b187"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-900"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="mailto:kunchalavenkatesh06@gmail.com"
              className="text-gray-600 hover:text-gray-900"
            >
              <Mail size={20} />
            </a>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <a href="#about" className="text-gray-600 hover:text-gray-900">About</a>
              <a href="#projects" className="text-gray-600 hover:text-gray-900">Projects</a>
              <a href="#skills" className="text-gray-600 hover:text-gray-900">Skills</a>
              <a href="#chat" className="text-gray-600 hover:text-gray-900">Chat</a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}