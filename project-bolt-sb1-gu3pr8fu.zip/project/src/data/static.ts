import { Project, Skill } from '../types';

export const projects: Project[] = [
  {
    id: 1,
    title: "AI-Powered Learning Platform for KV School Students",
    description: "Developed an AI platform to automate assignments, assessments, and provide personalized feedback, enhancing the learning experience. Streamlined learning processes and reduced administrative workload for KV school educators.",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&q=80&w=1000",  // Replace with actual project image link
    tags: ["Python", "LangChain", "FastAPI", "React"]
  },
  {
    id: 2,
    title: "Oxford Order Processing System (OUP)",
    description: "Built a robust order management system for Oxford University Press with real-time tracking and inventory management. Improved order fulfillment accuracy and processing efficiency.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1000",  // Replace with actual project image link
    tags: ["Python", "Django", "FastAPI", "PostgreSQL"]
  },
  {
    id: 3,
    title: "Healthcare Messenger App",
    description: "Created a healthcare messenger app with LLM-based chatbots for patient check-ins and daycare services. Integrated face detection and voice bot functionalities for a seamless user experience.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1000",  // Replace with actual project image link
    tags: ["Python", "LangChain", "FastAPI", "React"]
  },
  {
    id: 4,
    title: "Real-Time Object Detection (YOLOv8)",
    description: "Developed a custom YOLOv8 model for real-time detection of people, guns, and individuals in ghillie suits. Enhanced security and surveillance capabilities with fast and accurate object recognition.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=1000",  // Replace with actual project image link
    tags: ["Python", "YOLOv8", "OpenCV", "TensorFlow"]
  }
];


export const skills: Skill[] = [
  { name: "Python", level: 90, category: "Programming Languages & Frameworks" },
  { name: "LangChain", level: 85, category: "Programming Languages & Frameworks" },
  { name: "MySQL", level: 80, category: "Databases" },
  { name: "MongoDB", level: 85, category: "Databases" },
  { name: "VectorDB", level:80, category: "Databases" },
  { name: "Machine Learning", level: 80, category: "Machine Learning & AI" },
  { name: "Deep Learning", level: 80, category: "Machine Learning & AI" },
  { name: "Generative AI", level: 80, category: "Machine Learning & AI" },
  { name: "FastAPI", level: 80, category: "Programming Languages & Frameworks" },
  { name: "Docker", level: 75, category: "Tools" },
  { name: "GitHub", level: 85, category: "Tools" },
  { name: "Postman", level: 80, category: "Tools" },
  { name: "Linux (Ubuntu)", level: 85, category: "Infrastructure" },
  { name: "Streamlit", level: 80, category: "Frontend & Backend" }
];


export const chatbotResponses = {
  greeting: "Hello! I'm Venkatesh, an AI Engineer. How can I help you today?",
  default: "I'm not sure how to respond to that. Could you please rephrase?",
  keywords: {
    "project": "I'd be happy to discuss my AI and machine learning projects! Which one interests you?",
    "experience": "I have extensive experience in AI development, particularly with LangChain and GenAI solutions.",
    "contact": "You can reach me at kunchalavenkatesh06@gmail.com",
    "skills": "I specialize in Python, LangChain, Machine Learning, and AI technologies.",
    "hello": "Hi there! Nice to meet you!",
    "hi": "Hello! How can I assist you today?"
  }
};